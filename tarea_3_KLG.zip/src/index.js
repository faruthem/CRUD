import app from "./app";
import './database';
//import {PORT} from './config';
app.listen(3000);
console.log("LOS HURONES ESTÁN ESCUCHANDO EL SONIDO DE NUESTRA ALMA POR EL PUERTO", 3000);//PORT
